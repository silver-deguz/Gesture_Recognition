import numpy as np
from matplotlib import pyplot as plt
import pickle
import os 

from matplotlib import pyplot as plt
import matplotlib.image as mpimg
import numpy as np

import keras

from keras.preprocessing import image
from keras.models import Model
from keras.optimizers import RMSprop
from keras.layers import merge,Reshape
from keras.layers.normalization import BatchNormalization
from keras.layers import Input, Dense, Conv2D, MaxPooling2D,Conv2DTranspose, \
    UpSampling2D, Activation, LeakyReLU, Flatten, Dropout, GaussianNoise
from keras.models import Model,Sequential
from keras.callbacks import ModelCheckpoint
from keras.optimizers import Adadelta, RMSprop,SGD,Adam
from keras import regularizers
from keras import backend as K
from keras.utils import to_categorical
from keras.utils import np_utils

import tensorflow
from tensorflow.keras.metrics import categorical_accuracy, top_k_categorical_accuracy

import sklearn
import sklearn.metrics as metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils import shuffle
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report

import pickle
import os



def load():
    '''
    loads and concatenates data files into numpy array
    '''
    path = os.getcwd()
    temp = path
    path = path + '/data/'
    os.chdir(path)
    data = []
    labels = []
    directories = []
    for out_files in os.listdir():
        
        if out_files == 'Gesture_Recognition.ipynb':
            continue
        if not out_files.startswith('.'):
           # print('Reading file ',out_files,'...')
            if (out_files == 'output_lb.p'):
                read_file =  path + out_files
                labels = pickle.load( open( read_file, "rb" ) )
                continue
            directories.append(out_files)
            directories.sort(key=lambda x: int(x[10:12]) if len(x)==14 else int(x[10:11]))
    for i in directories:
        read_file =  path  + i
        data_t = pickle.load( open( read_file, "rb" ) )    
        data.append(data_t)
 
    directories.sort()
 
    ln = len(data)
    im_ln = len(data[0][0])
    M     = len(data[0])
    label = np.array(labels[0:ln*M])
    dataa = np.zeros((M*ln,im_ln,im_ln,1))
    l = 0
    for i in data:
       for j in i:
            dataa[l,:,:,0] = j
            l = l +1
    os.chdir(temp)
    
    data = np.array(dataa)
    data = data.reshape(-1, 120,120, 1)
    labels = np.array(label)
    
    #show image of dataset
    image = mpimg.imread('dataset.png')
    plt.figure(figsize = (15,30))
    plt.imshow(image)
    plt.axis("off")
    plt.show()
    
    return   data, labels    



def train_test_split(data, labels, train_prct, val_prct, test_prct):
    '''
    shuffle and split data into training, validaiton, and testing
    '''
    assert train_prct+val_prct+test_prct == 1
    
    data, labels = shuffle(data, labels, random_state=1)

    train_data = data[0:int(train_prct*data.shape[0]),:,:,:]
    train_labels = labels[0:int(train_prct*data.shape[0])]

    val_data = data[int(train_prct*data.shape[0]):int(train_prct*data.shape[0]+val_prct*data.shape[0]),:,:,:]
    val_labels = labels[int(train_prct*data.shape[0]):int(train_prct*data.shape[0]+val_prct*data.shape[0])]

    test_data = data[int(train_prct*data.shape[0]+val_prct*data.shape[0]):,:,:,:]
    test_labels = labels[int(train_prct*data.shape[0]+val_prct*data.shape[0]):]
    return data, labels, train_data, train_labels, val_data, val_labels, test_data, test_labels



def one_hot_encoder(train_labels, val_labels, test_labels):
    '''
    one-hot label encoder for label set
    '''
    encoder = LabelEncoder()
    encoder.fit(train_labels)
    encoded_labels = encoder.transform(train_labels)
    train_labels_onehot = np_utils.to_categorical(encoded_labels)

    encoder.fit(val_labels)
    encoded_labels = encoder.transform(val_labels)
    val_labels_onehot = np_utils.to_categorical(encoded_labels)

    encoder.fit(test_labels)
    encoded_labels = encoder.transform(test_labels)
    test_labels_onehot = np_utils.to_categorical(encoded_labels)
    return train_labels_onehot, val_labels_onehot, test_labels_onehot
    
    
    
def plot_label_counts(train_labels):
    '''
    plots histogram of label counts
    '''
    unique, counts = np.unique(train_labels, return_counts=True)
    labels = ['palm','L','fist','fist side','thumb','index','OK','palm side','C','down']
    
    plt.figure()
    plt.bar(unique,counts,width=0.5,color =(0.4,0.2,1.0),tick_label = labels)
   # plt.xticks(unique,range(len(unique)))
    plt.xticks(rotation = 30)
    plt.ylabel('Counts')
    plt.xlabel('Classes')
    plt.title('Frequency of classes in training set')
    plt.show()
    
    
    
def CNN():
    '''
    defines architecture of CNN
    '''
    input_img = Input(shape=(120, 120, 1))
    x = Conv2D(128, (3, 3), activation='relu', padding='same', dilation_rate=(2,2))(input_img)
    x = GaussianNoise(0.0036)(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2), padding='same')(x)

    x = Conv2D(64, (3, 3), activation='relu', padding='same', dilation_rate=(2,2))(x)
    x = GaussianNoise(0.0035)(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2), padding='same')(x)

    x = Conv2D(32, (3, 3), activation='relu', padding='same', dilation_rate=(2,2))(x)
    x = GaussianNoise(0.003)(x)
    x = BatchNormalization()(x)
    x = MaxPooling2D((2, 2), padding='same')(x)
    
    x = Flatten()(x)
    x = Dense(128, activation='relu')(x)
    x = Dropout(0.5)(x)
    output = Dense(10, activation='softmax')(x) #for 10 classes
    return Model(input_img, output)



def top_3_accuracy(y_true, y_pred):
    return top_k_categorical_accuracy(y_true, y_pred, k=3)



def top_2_accuracy(y_true, y_pred):
    return top_k_categorical_accuracy(y_true, y_pred, k=2)



def show_training(my_CNN_train, epochs):
    '''
    show training results
    '''
    loss = my_CNN_train.history['loss']
    val_loss = my_CNN_train.history['val_loss']
    epchs = range(epochs)
    fig = plt.figure(figsize=(10, 10))
    plt.figure()
    plt.plot(epchs, loss,color='blue', label='Training loss')
    plt.plot(epchs, val_loss,color='darkorange', label='Validation loss')
    plt.title('Training and validation loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()
    
    
    
def display_activation(activations, col_size, row_size, act_index): 
    '''
    show output of network layers
    '''
    activation = activations[act_index]
    activation_index=0
    fig, ax = plt.subplots(row_size, col_size, figsize=(row_size*3,col_size*3))
    plt.axis("off")
    fig.suptitle('Output of layer ' + str(act_index) +':', fontsize=16)
    for row in range(0,row_size):
        for col in range(0,col_size):
            ax[row][col].imshow(activation[0, :, :, activation_index], cmap='viridis')
            activation_index += 1

            
            
def show_correct_labels(correct, predicted_classes, test_data, test_labels):
    '''
    show correctly labeled images
    '''
    print('Found %d correct labels' %len(correct))
    fig = plt.figure(figsize=(10, 10))
    for i, correct in enumerate(correct[:9]):
        plt.subplot(3,3,i+1)
        plt.imshow(test_data[correct].reshape(120,120), cmap='gray', interpolation='none')
        plt.title("Class {}, Predicted {}".format(test_labels[correct],predicted_classes[correct]))
        plt.tight_layout()

    

def show_incorrect_labels(incorrect, predicted_classes, test_data, test_labels):
    '''
    show incorrectly labeled images
    '''
    print('Found %d incorrect labels' % len(incorrect))
    fig = plt.figure(figsize=(10, 10))
    for i, incorrect in enumerate(incorrect[18:27]):
        plt.subplot(3,3,i+1)
        plt.imshow(test_data[incorrect].reshape(120,120), cmap='gray', interpolation='none')
        plt.title("Predicted {}, Class {}".format(predicted_classes[incorrect], test_labels[incorrect]))
        plt.tight_layout()
    
    
def plot_conf_matrix(classes, confusion_matrix):
    '''
    plot confusion matrix
    '''
    fig = plt.figure(figsize=(10, 10))
    plt.imshow(confusion_matrix, cmap='plasma')
    plt.xticks(np.arange(10), list(classes.values()))
    plt.xlabel("Predicted Labels", fontsize=15)
    plt.yticks(np.arange(10), list(classes.values()))
    plt.ylabel("True Labels", fontsize=15)
    plt.colorbar()
    plt.title("Normalized Confusion Matrix", fontsize=20)

    
def load_DEMO():
    '''
    loads demo data
    '''
    path = os.getcwd()
    temp = path
    path = path + '/data_DEMO/'
    os.chdir(path)
    data = np.load('data_DEMO.npy')
    labels = np.load('labels_DEMO.npy')
    os.chdir(temp)
    image = mpimg.imread('dataset.png')
    plt.figure(figsize = (15,30))
    plt.imshow(image)
    plt.axis("off")
    plt.show()
    return data, labels